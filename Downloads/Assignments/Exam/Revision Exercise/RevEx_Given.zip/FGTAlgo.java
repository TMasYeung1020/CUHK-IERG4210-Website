public class FGTAlgo {             // modelling the algorithms
	public static final int CONST_N = 10;// default number of iterations
	public static final int CONST_K = 48;// default size of the array fMean
	private int coeff01 = 1, coeff02 = 2;	// coefficient 1 and 2
	private int fNumIte;         // number of iterations	 
	         

	FGTAlgo(int numi, int size){
		fNumIte = numi;
		fMean = new double[size]; 
	}

	void setCoeff(int coeff01, int coeff02) {
     // TO BE COMPLETED

	}

	void setNumIte(int numi) {
     // TO BE COMPLETED

	}

	public int getNumIte() {
		return fNumIte; 		
	}
	
	public String getAlgoInfo(){ 
		return "No. of iterations = " + fNumIte;
	}
	

}
