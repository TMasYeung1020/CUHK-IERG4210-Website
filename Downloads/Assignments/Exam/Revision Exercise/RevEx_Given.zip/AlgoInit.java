public interface AlgoInit { // an Interface 
	// Method for initialization of the algorithm	
    // TO BE COMPLETED

}
