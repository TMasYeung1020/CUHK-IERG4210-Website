public class Struct4D { // Fields & methods for the component mct of an algorithm
	public int aRateW;  // rateW 
	public String aLabel; // a label for the component
	// ... Ignore MORE details here
	
	Struct4D(int rateW){
		aRateW = rateW;
		// ... Ignore other details here
	}
	
	Struct4D(int rateW, String label){
		this(rateW);
		aLabel = label;
		// ... Ignore other details here
	}

	public void aCalOffset(){ 
		// ... Ignore details here
	}	
	
	public void aSelectPath_00(){ 
		// ... Ignore details here
	}	

	public void aSelectPath_01(){ 
		// ... Ignore details here
	}	
	
// .....	
	
}




