// StudentInfoFileUtil.java, For A4, OOP, 2022
// Given: To be FINISHED by student
/**
 * @author Student: <StudentName>, <SID>, <Class>, <Year>
 */
 
import java.io.*;
import java.util.ArrayList;
public class StudentInfoFileUtil { // declare a class
    
    public static StudentInfo[] readStudFile(String rStudFile){  // DO NOT MODIFY the method header
        // .. TO BE COMPLETED BY STUDENTS ..
    }
    
    public static void writePTStudFile(StudentInfo[] sArr, String wSFile){  // DO NOT MODIFY the method header
        // .. TO BE COMPLETED BY STUDENTS ..
    }
    
    public static void writeStudObjectFile(StudentInfo[] sArr, String wSObjF){  // DO NOT MODIFY the method header
        // .. TO BE COMPLETED BY STUDENTS ..
    }
    
    public static StudentInfo[] readStudObjectFile(String rSObjF){  // DO NOT MODIFY the method header
        // .. TO BE COMPLETED BY STUDENTS ..
    }
}
