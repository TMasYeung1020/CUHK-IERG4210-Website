#include<stdio.h>
#include<stdlib.h>
#include<string.h>


int main(int argc, char *argv[]) {
	
	FILE *fin, *fout;
	int i, j, n;
	char line[102] = {0};
	char key[50][102] = {0}, value[50][102] = {0}, input[102] = {0}, output[102] = {0};
	
	fin = fopen(argv[1], "r");
	fout = fopen(argv[2], "w");
	
	fscanf(fin, "%d\n", &n);
	
	for (i = 0; i < n; i++) {
		fgets(line, 102, fin);
		// Your code here
		
		
		
		memset(line, 0, sizeof(line));
	}
	
	fgets(input, 102, fin);
	input[strlen(input)-1] = 0;
	
	// Your code here
	
	
	
	
	// output format
	fprintf(fout, "%s\n", output);
	
	fclose(fin);
	fclose(fout);
	
	return 0;
}
