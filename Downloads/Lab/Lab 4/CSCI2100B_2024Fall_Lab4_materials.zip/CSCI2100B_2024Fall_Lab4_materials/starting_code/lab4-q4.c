#include<stdio.h>
#include<stdlib.h>
#include<string.h>

// update the functions below
int f1(int x, int n) { return 0; }
int f2(int x, int n) { return 0; }
int f3(int x, int n) { return 0; }

int main(int argc, char *argv[]) {
	
	FILE *fin, *fout;
	int n, i, j, num, is_exist = 1;
	char cmd[105];
	int bloom[101] = {0};
	
	fin = fopen(argv[1], "r");
	fout = fopen(argv[2], "w");
	
	memset(cmd, 0, sizeof(cmd));
	
	fscanf(fin, "%d", &n);

	while (fscanf(fin, "%s", cmd) > 0) {
		if (strcmp(cmd, "insert") == 0) {
			fscanf(fin, "%d", &num);
			// Your code here
			
			
		} else if (strcmp(cmd, "query") == 0) {
			fscanf(fin, "%d", &num);
			// Your code here
			
			
			// Output format
			if (is_exist) fprintf(fout, "Yes\n");
			else fprintf(fout, "No\n");
		} else if (strcmp(cmd, "display") == 0) {			
			// Output format
			for (i = 0; i < n; i++) {
				fprintf(fout, "%d", bloom[i]);
			}
			fprintf(fout, "\n");
		}
		
		memset(cmd, 0, sizeof(cmd));
	}
	
	fclose(fin);
	fclose(fout);
	
	return 0;
}
