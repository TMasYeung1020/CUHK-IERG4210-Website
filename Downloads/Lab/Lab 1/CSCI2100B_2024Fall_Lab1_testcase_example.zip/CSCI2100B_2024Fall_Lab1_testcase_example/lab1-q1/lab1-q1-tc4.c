#include"lab1-q1.h"
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<limits.h>
#include<math.h>

int main(int argc, char *argv[]){

	FILE *fout;
	Node *list, *ptr;
	int isCorrect, i;	
	double arr[] = {4.21, 3.21, 2.21, 1.21};
	int arr_size = 4;
	double test_value = 1000.21;
	fout = fopen(argv[1], "w");
	
	/* default, your program is correct */
	isCorrect = 1;
	
	/* check the function, list_insert() */
	list = malloc(sizeof(Node));
	list->value = test_value;
	list->next = NULL;
	for (i = 0; i < arr_size; i++) {
		list = list_insert(list, arr[i]);
	}
	
	/* if list_insert() is not implemented appropriately */
	ptr = list;
	for (i = 0; i < arr_size; i++) {
		if (fabs(ptr->value-arr[arr_size-i-1]) > 1e-4) {
			isCorrect = 0;
		}
		ptr = ptr->next;
	}
	if (fabs(ptr->value-test_value) > 1e-4) {
		isCorrect = 0;
	}
	if (ptr->next != NULL) isCorrect = 0;	
		
	/* output "Correct" if test case is passed */
	if (isCorrect == 1) {
		fprintf(fout, "List: Correct\n");
	} else {
		fprintf(fout, "List: Wrong Answer\n");
	}
	fclose(fout);

	return 0;
}
