#include"lab1-q1.h"
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<limits.h>
#include<math.h>

int main(int argc, char *argv[]){

	FILE *fout;
	Node *list, *ptr;
	int isCorrect, i;	
	double arr[] = {1.6, 2.6, 3.6, 4.6, 5.6, 6.6, 7.6, 8.6};
	int arr_size = 8;
	int ans1, ans2, ans3, value1, value2, value3;
	fout = fopen(argv[1], "w");
	
	/* default, your program is correct */
	isCorrect = 1;
	
	/* check the function, list_contain() */
	list = NULL;
	for (i = 0; i < arr_size; i++) {
		ptr = malloc(sizeof(Node));
		ptr->value = arr[i];
		ptr->next = list;
		list = ptr;
	}
	value1 = list_contain(list, 7.6);
	value2 = list_contain(list, -0.6);
	value3 = list_contain(list, 4.46);
	ans1 = 1;
	ans2 = 0;
	ans3 = 0;
	
	
	/* if list_contain() is not implemented appropriately */
	if (ans1 != value1 || ans2 != value2 || ans3 != value3)
		isCorrect = 0;	
		
	/* output "Correct" if test case is passed */
	if (isCorrect == 1) {
		fprintf(fout, "List: Correct\n");
	} else {
		fprintf(fout, "List: Wrong Answer\n");
	}
	fclose(fout);

	return 0;
}
