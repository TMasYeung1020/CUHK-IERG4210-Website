#include"lab1-q1.h"
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<limits.h>
#include<math.h>

int main(int argc, char *argv[]){

	FILE *fout;
	Node *list, *ptr;
	int isCorrect, i;	
	double arr[] = {1.6, 2.6, 3.6, 4.6, 5.6, 6.6, 7.6, 8.6};
	int arr_size = 8;
	fout = fopen(argv[1], "w");
	
	/* default, your program is correct */
	isCorrect = 1;
	
	/* check the function, list_free() */
	list = NULL;
	for (i = 0; i < arr_size; i++) {
		ptr = malloc(sizeof(Node));
		ptr->value = arr[i];
		ptr->next = list;
		list = ptr;
	}
	list_free(&list);
	
	/* if list_free() is not implemented appropriately */
	if (list != NULL) isCorrect = 0;	
		
	/* output "Correct" if test case is passed */
	if (isCorrect == 1) {
		fprintf(fout, "List: Correct\n");
	} else {
		fprintf(fout, "List: Wrong Answer\n");
	}
	fclose(fout);

	return 0;
}
