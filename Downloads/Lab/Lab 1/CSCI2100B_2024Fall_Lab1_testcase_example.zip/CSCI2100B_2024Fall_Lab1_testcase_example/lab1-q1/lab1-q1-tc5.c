#include"lab1-q1.h"
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<limits.h>
#include<math.h>

int main(int argc, char *argv[]){

	FILE *fout;
	Node *list, *ptr;
	int isCorrect, i;	
	double arr[] = {8, 7, 6, 5, 4, 3, 2, 1};
	int arr_size = 8;
	fout = fopen(argv[1], "w");
	
	/* default, your program is correct */
	isCorrect = 1;
	
	/* check the function, list_delete() */
	list = NULL;
	for (i = 0; i < arr_size; i++) {
		ptr = malloc(sizeof(Node));
		ptr->value = arr[i];
		ptr->next = list;
		list = ptr;
	}
	list = list_delete(list, 0);
	
	/* if list_delete() is not implemented appropriately */
	ptr = list;
	for (i = 0; i < arr_size; i++) {
		if (fabs(ptr->value-arr[arr_size-i-1]) > 1e-4) {
			isCorrect = 0;
		}
		ptr = ptr->next;
	}
	if (ptr != NULL) isCorrect = 0;	
		
	/* output "Correct" if test case is passed */
	if (isCorrect == 1) {
		fprintf(fout, "List: Correct\n");
	} else {
		fprintf(fout, "List: Wrong Answer\n");
	}
	fclose(fout);

	return 0;
}
