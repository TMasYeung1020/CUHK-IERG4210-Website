#include"lab1-q2.h"
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<limits.h>

int main(int argc, char *argv[]){

	FILE *fout;
	ArrayList *list;
	int isCorrect, i;	
	char arr[100][51] = {"I", "love", "studying", "Data", "Structure"};
	int arr_size = 5;
	int ans1, ans2, ans3, ans4;
	int value1, value2, value3, value4;
	fout = fopen(argv[1], "w");
	
	/* default, your program is correct */
	isCorrect = 1;
	
	/* check the function, arraylist_size() */
	list = malloc(sizeof(ArrayList));
	memset(list, 0, sizeof(ArrayList));
	list->first = 97;
	list->last = 96;
	value1 = arraylist_size(list);
	ans1 = 99;
	list->first = 26;
	list->last = 26;
	value2 = arraylist_size(list);
	ans2 = 0;
	list->first = 88;
	list->last = 12;
	value3 = arraylist_size(list);
	ans3 = 24;
	list->first = 16;
	list->last = 71;
	value4 = arraylist_size(list);
	ans4 = 55;
	
	/* if arraylist_size() isn't implemented appropriately */
	if (list == NULL) {
		isCorrect = 0;
	} else if (ans1 != value1 || ans2 != value2 || ans3 != value3 || ans4 != value4) {
		isCorrect = 0;
	} 
		
	/* output "Correct" if test case is passed */
	if (isCorrect == 1) {
		fprintf(fout, "List: Correct\n");
	} else {
		fprintf(fout, "List: Wrong Answer\n");
	}
	fclose(fout);

	return 0;
}