#include"lab1-q2.h"
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<limits.h>

int main(int argc, char *argv[]){

	FILE *fout;
	ArrayList *list;
	int isCorrect, i;	
	char arr[100][51] = {"I", "love", "studying", "Data", "Structure"};
	int arr_size = 5;
	char *cptr;
	fout = fopen(argv[1], "w");
	
	/* default, your program is correct */
	isCorrect = 1;
	
	/* check the function, arraylist_deletefirst() */
	list = malloc(sizeof(ArrayList));
	memset(list, 0, sizeof(ArrayList));
	list->first = 97;
	list->last = 96;
	for (i = 0; i < arr_size; i++) {
		cptr = arraylist_deletefirst(list);
		if (cptr == NULL) isCorrect = 0;
	}
	
	/* if arraylist_deletefirst() isn't implemented appropriately */
	if (list == NULL) {
		isCorrect = 0;
	} else if (list->first != 2 || list->last != 96) {
		isCorrect = 0;
	} 
		
	/* output "Correct" if test case is passed */
	if (isCorrect == 1) {
		fprintf(fout, "List: Correct\n");
	} else {
		fprintf(fout, "List: Wrong Answer\n");
	}
	fclose(fout);

	return 0;
}