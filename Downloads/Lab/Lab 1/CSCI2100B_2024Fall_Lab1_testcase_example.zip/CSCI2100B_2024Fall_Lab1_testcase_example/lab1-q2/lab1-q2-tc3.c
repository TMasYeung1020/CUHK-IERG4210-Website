#include"lab1-q2.h"
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<limits.h>

int main(int argc, char *argv[]){

	FILE *fout;
	ArrayList *list;
	int isCorrect, i;	
	char arr[100][51] = {"I", "love", "studying", "Data", "Structure"};
	int arr_size = 5;
	fout = fopen(argv[1], "w");
	
	/* default, your program is correct */
	isCorrect = 1;
	
	/* check the function, arraylist_insert() */
	list = malloc(sizeof(ArrayList));
	memset(list, 0, sizeof(ArrayList));
	list->first = 96;
	list->last = 99;
	for (i = 0; i < arr_size; i++)
		arraylist_insert(list, arr[i]);
	
	/* if arraylist_insert() isn't implemented appropriately */
	if (list == NULL) {
		isCorrect = 0;
	} else if (list->first != 96 || list->last != 4) {
		isCorrect = 0;
	} else {
		for (i = 0; i < arr_size; i++) {
			if (strcmp(list->word[(99+i)%100], arr[i]) != 0) 
				isCorrect = 0;
		}
	} 
		
	/* output "Correct" if test case is passed */
	if (isCorrect == 1) {
		fprintf(fout, "List: Correct\n");
	} else {
		fprintf(fout, "List: Wrong Answer\n");
	}
	fclose(fout);

	return 0;
}