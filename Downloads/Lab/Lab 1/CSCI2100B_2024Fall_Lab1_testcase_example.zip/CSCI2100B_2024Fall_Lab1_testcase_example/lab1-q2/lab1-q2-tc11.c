#include"lab1-q2.h"
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<limits.h>

int main(int argc, char *argv[]){

	FILE *fout;
	ArrayList *list;
	int isCorrect, i;	
	char arr[100][51] = {"I", "love", "studying", "Data", "Structure"};
	int arr_size = 5;
	char ans[] = "I love studying Data Structure ";
	char *value;
	fout = fopen(argv[1], "w");
	
	/* default, your program is correct */
	isCorrect = 1;
	
	/* check the function, arraylist_print */
	list = malloc(sizeof(ArrayList));
	memset(list, 0, sizeof(ArrayList));
	list->first = 97;
	list->last = 2;
	for (i = 0; i < arr_size; i++) {
		strcpy(list->word[(list->first+i)%100], arr[i]);
	}
	value = arraylist_print(list);
	
	/* if arraylist_print() isn't implemented appropriately */
	if (list == NULL) {
		isCorrect = 0;
	} else if (strcmp(ans, value) != 0) {
		isCorrect = 0;
	} 
		
	/* output "Correct" if test case is passed */
	if (isCorrect == 1) {
		fprintf(fout, "List: Correct\n");
	} else {
		fprintf(fout, "List: Wrong Answer\n");
	}
	fclose(fout);

	return 0;
}
