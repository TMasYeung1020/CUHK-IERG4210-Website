#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<limits.h>
#include<math.h>

int main (int argc, char *argv[]){
	FILE * fin, *fout;

    // input and output files
    fin = fopen(argv[1], "r");
	fout = fopen(argv[2], "w");

    char s[102]; // the string that store the input parentheses  
	memset(s,0,sizeof(s));
	
    // read from the input file
    fscanf(fin, "%s", s);


    // Your code here


    /* About the output format:
    1) If the parentheses are balanced, you may use the following function to write the answer to the output file:
    
    fprintf(fout, "There are %d balanced parentheses.", count);
    
    where ``count'' is the int variable that store the number of balanced parentheses

    2) If the parentheses are unbalanced, you may use the following function to write the answer to the output file:

    fprintf(fout, "Error is spot at position %d at first.", error);

    where ``error'' is the int variable that indicate the first position (zero-based) that you spot an error.
    */

    fclose(fin);
	fclose(fout);

	return 0;
}
