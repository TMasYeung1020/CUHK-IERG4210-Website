#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<limits.h>
#include<math.h>

typedef struct point {
	int x, y;
	double slope;
} Point;

int isConvex(Point p1, Point p2, Point p3) { 
	/* if collinear, return 0 */
	if ((p2.y-p1.y)*(p3.x-p2.x) == (p3.y-p2.y)*(p2.x-p1.x)) {
		return 0;
	}
	
	/* if convex, return 1 */
	if ((p2.x-p1.x)*(p3.y-p2.y) > (p3.x-p2.x)*(p2.y-p1.y)) {
		return 1;
	}
		
	/* return 0 (i.e. concave) */
	return 0;
}

int main (int argc, char *argv[]){

	FILE * fin, *fout;
	int n;
	Point p[101];

	fin = fopen(argv[1], "r");
	fout = fopen(argv[2], "w");
	
	memset(p, 0, sizeof(p));

	/* read input */
	fscanf(fin, "%d", &n);
	for (int i = 0; i < n; i++) {
		fscanf(fin, "%d%d", &p[i].x, &p[i].y);
		if (i != 0) p[i].slope = 1.0*p[i].y/p[i].x;
	}
	
    // Your code here


	fclose(fin);
	fclose(fout);
	return 0;
}

