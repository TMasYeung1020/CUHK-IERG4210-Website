// lab3-q1.h 

// Cannot modify: struct queue, MAX_SIZE 
#define MAX_SIZE 100
struct queue{
	int data[MAX_SIZE]; 
    int front; // The front of the queue
    int rear;  // The rear of the queue, the next position where a new item can enqueue if the queue is not full.
    int size;  // The size of the queue
};
typedef struct queue Queue;

// Return a new empty queue --Testcase #1 #10
// An empty queue has 0 values for front, rear and size
void queue_init(Queue** q);

// Make the queue empty --Testcase #2 #10
// An empty queue has 0 values for front, rear and size 
void queue_make_empty(Queue* q);

// Return the size of the queue --Testcase #3 #10
int queue_size(Queue* q);

// Check if the queue is empty --Testcase #4 #10
// Return 1 if queue is empty
// Return 0 if queue is not empty 
int queue_is_empty(Queue* q);

// Check if the queue is full --Testcase #5 #10
// Return 1 if queue is full
// Return 0 if queue not full 
int queue_is_full(Queue* q);

// If the queue is not full, enqueue the value x to the rear of the queue --Testcase #6 #10
void queue_enqueue(Queue* q, int x);

// If q is not empty, dequeue and return the front of the queue --Testcase #7 #10
// If the queue is empty, return INT_MAX 
int queue_dequeue(Queue* q);

// Free the queue, if the queue is not NULL --Testcase #8 #10
// Assign NULL to q after free 
void queue_free(Queue** q);

// Print the queue in the format --Testcase #9 #10
// e.g. q: 0 1 2 3, where 0 is the front 
// output: "(front) 0 1 2 3 (rear)" 
char* queue_print(Queue* q);
