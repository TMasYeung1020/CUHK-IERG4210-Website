#include"lab3-q2.h"
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<limits.h>

// Return a new empty stack --Testcase #1 #10
// An empty stack is a node with data storing CHAR_MAX and next pointing to NULL 
void stack_init(Stack** s){
    // Your code here
}

// Make the stack empty --Testcase #2 #10
// An empty stack is data storing CHAR_MAX and next pointing to NULL 
void stack_make_empty(Stack* s){
    // Your code here
}

// Return the size of the stack --Testcase #3 #10
int stack_size(Stack* s){
    // Your code here
}

// Check if the stack is empty --Testcase #4 #10
// Return 1 if the stack is empty
// Return 0 if the stack is not empty 
int stack_is_empty(Stack* s){
    // Your code here
}

// Push the value x to the top of the stack --Testcase #5 #10
void stack_push(Stack* s, char x){
    // Your code here
}

// Return the topmost element of the stack --Testcase #6 #10
// If the stack is empty, return 0 
char stack_top(Stack* s){
    // Your code here
}

// If s is not empty, pop an element from the stack --Testcase #7 #10
// If s is empty, do nothing
void stack_pop(Stack* s){
    // Your code here
}

// Free the stack, if the stack is not NULL --Testcase #8 #10
// Assign NULL to s after free 
void stack_free(Stack** s){
    // Your code here
}

// Print the stack in the format
// e.g. stack: d->c->b->a, where d is the topmost element 
// output: "(top) d c b a" --Testcase #9 #10
// This function should return a string containing the output.
char* stack_print(Stack* s){
    // Your code here
}


